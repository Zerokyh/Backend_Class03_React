import { FaMagnifyingGlass } from "react-icons/fa6";

const Topnav = () => {
  return (
    <div className="flex justify-end">
      <FaMagnifyingGlass />
    </div>
  );
};

export default Topnav;
