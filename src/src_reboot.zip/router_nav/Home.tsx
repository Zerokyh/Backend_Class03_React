const Home = () => {
  return (
    <section className="w-full h-96 flex justify-center items-center ">
      아무튼 홈페이지 화면임
    </section>
  );
};

export default Home;
