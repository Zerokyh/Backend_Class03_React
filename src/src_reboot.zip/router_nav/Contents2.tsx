const Contents2 = () => {
  return (
    <section className="w-full h-96 flex justify-center items-center ">
      아무튼 마이 화면임
    </section>
  );
};

export default Contents2;
