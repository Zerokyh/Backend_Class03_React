const Contents1 = () => {
  return (
    <section className="w-full h-96 flex justify-center items-center ">
      아무튼 티켓 / 예약 화면임
    </section>
  );
};

export default Contents1;
