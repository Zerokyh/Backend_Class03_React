const Logo = () => {
  return (
    <div className="flex justify-center items-center gap-3">
      <div className="w-16 h-16 object-cover">
        <img className="w-full h-full rounded-full" src="./man.jpg" alt="" />
      </div>
      <span className="font-pyeongchang text-xl hover:text-stone-200">
        ZERO
      </span>
    </div>
  );
};

export default Logo;
