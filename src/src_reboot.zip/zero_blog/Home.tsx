const Home = () => {
  return (
    <div className="max-w-screen-2xl w-svw h-full flex justify-center items-center">
      아무튼 홈 화면임 ㅋㅋㅋ
    </div>
  );
};

export default Home;
