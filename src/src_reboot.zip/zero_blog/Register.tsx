const Register = () => {
  return (
    <div className="max-w-screen-2xl w-svw h-full flex justify-center items-center">
      회원가입 페이지
    </div>
  );
};

export default Register;
